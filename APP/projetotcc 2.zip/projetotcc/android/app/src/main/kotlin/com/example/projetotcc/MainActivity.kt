package com.example.projetotcc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

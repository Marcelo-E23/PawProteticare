import { BrowserRouter, Route, Routes } from "react-router-dom";
import Login from "./pages/Login";
import Home from "./pages/Home";
import Animal from "./pages/Animal";
import AlterarAnimal from "./pages/AlterarAnimal";
import CadastroAnimal from "./pages/CadastroAnimal";
import VisualizarAnimal from "./pages/VisualizarAnimal";
import Doador from "./pages/Doador";

export default function AppRoutes(){
    return(
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Login/>}/>
                <Route path="/Home" element={<Home/>}/>
                <Route path="/Animal" element={<Animal/>}/>
                <Route path="/AlterarAnimal/:id" element={<AlterarAnimal/>}/>
                <Route path="/CadastroAnimal" element={<CadastroAnimal/>}/>
                <Route path="/VisualizarAnimal/:id" element={<VisualizarAnimal/>}/>
                <Route path="/Doador" element={<Doador/>}/>
            </Routes>
        </BrowserRouter>
    )
}
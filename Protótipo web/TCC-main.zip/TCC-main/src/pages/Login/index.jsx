import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import endFetch from '../../axios';
import style from './login.module.css';
import botao from '../../css/botao.module.css'

const Login = () => {
  const [login, setLogin] = useState('');
  const [senha, setSenha] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const loginData = await endFetch.get('/usuarios');
      const user = loginData.data.find(
        (item) => item.login === login && item.senha === senha,
        console.log(loginData),
      );
      
      if (user) {
        navigate('/home');
      } 
      else {
        setError('Usuário ou senha incorretos');
      }
    }

    catch (error) {
      setError('Erro ao fazer login');
    }
  };

  return (
    <div className={style.login}>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="usuario">Usuário</label>
          <input 
            type="text"
            id="usuario"
            value={login}
            onChange={(e) => setLogin(e.target.value)}
            required
            placeholder="Digite seu usuário"
          />
        </div>
        <div>
          <label htmlFor="senha">Senha</label>
          <input
            type="password"
            id="senha"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            required
            placeholder="Digite sua senha"
          />
        </div>
        {error && <p className={style.erro}>{error}</p>}
        <button className={botao.bblue}type="submit">Entrar</button>
      </form>
    </div>
  );
};

export default Login;

import React, { useState } from "react";
import Header from "../../components/Header";
import Voltar from "../../components/Voltar";
import endFetch from "../../axios";  
import { useNavigate } from "react-router-dom";
import style from './cadastro.module.css';
import styles from '../../css/input.module.css'
import { Link } from "react-router-dom";
import Input from "../../modelos/Inputcadastro";
import botao from '../../css/botao.module.css'


const CadastroAnimal = () => {
  const [nome, setNome] = useState("");
  const [protese, setProtese] = useState("");
  const [especie, setEspecie] = useState("");
  const [idade, setIdade] = useState("");
  const [imagem, setImagem] = useState("");
  const [status, setStatus] = useState("Esperando Protése");
  const [historia, setHistoria] = useState("");
  const [message, setMessage] = useState("");  
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault(); 
    const novoAnimal = {
      nome,
      protese,
      especie,
      idade,
      status,
      historia,
      imagem,
    };

    try {
      const response = await endFetch.post("/animais", novoAnimal);
      
      setMessage(`Animal cadastrado com sucesso: ${response.data.nome}`);
      
      navigate('/Animal');
      
      
    } catch (error) {
      setMessage("Erro ao cadastrar o animal. Tente novamente.");
    }

    const navVoltar = () =>{
        navigate('/Animal')
    } 

  };

  return (
    <>
      <Header/>
      <div className={style.cadastro}>
        <form onSubmit={handleSubmit}>
          <Link to={'/Animal'}><Voltar/></Link>

          <Input dado={"Nome"} legenda={"Digite o Nome:"} tipo={"text"} valor={nome} change={(e) => setNome(e.target.value)} />
          <Input dado={"Especie"} legenda={"Digite a Especie:"} tipo={"text"} valor={especie} change={(e) => setEspecie(e.target.value)} />
          <Input dado={"Idade"} legenda={"Digite a Idade:"} tipo={"number"} valor={idade} change={(e) => setIdade(e.target.value)} />
          <Input dado={"Protése"} legenda={"Digite a Necessidade de Protése do animal:"} tipo={"text"} valor={protese} change={(e) => setProtese(e.target.value)} />
          <div className={styles.input}>
            <label htmlFor="status" className="form-label">Status:</label>
            <select 
            id="status" 
            name="status" 
            value={status} 
            onChange={(e) => setStatus(e.target.value)}
            required>   
                        <option value="Esperando Protese">Esperando Protése</option>
                        <option value="Adotado">Adotado</option>
                        <option value="Esperando Cirurgia">Esperando Cirurgia</option>
                        <option value="Falecido">Falecido</option>
          </select>
          </div>
          <Input dado={"História"} legenda={"Digite a História do animal:"} tipo={"textarea"} valor={historia} change={(e) => setHistoria(e.target.value)}/>
        

          <div className={styles.input}>
            <label>Imagem do Animal</label>
              <input 
                type="file" 
                accept="image/*" 
                onChange={(e) => {
                  const file = e.target.files[0];
                  const reader = new FileReader();
                  reader.onloadend = () => {
                    setImagem(reader.result); 
                  };
              if (file) {
                reader.readAsDataURL(file);
              }
              }}/>
          </div>
        {message && <p className={style.errocadastro}>{message}</p>}
          
          <button className={botao.bgreen} type="submit">Cadastrar</button>
        </form>
      </div>
    </>
  );
};

export default CadastroAnimal;

import Header from '../../components/Header';
import styles from './doador.module.css';
import { Link, useParams } from 'react-router-dom';
import endFetch from '../../axios';
import 'bootstrap/dist/css/bootstrap.min.css'
import { useEffect, useState } from 'react';
import style from './doador.module.css';

export default function Doador(){
    const [doador, setDoador] = useState([]);
    const [loading, setLoading] = useState(true);
    
    const getDoador = async () => {
        try {
            const response = await endFetch.get("/doadores"); 
            setDoador(response.data);
            console.log(doador) 
        } catch (error) {
            console.error(<p className={style}>Erro ao carregar os dados</p>, error);
        } finally {
            setLoading(false); 
        }
    };

    useEffect(() => {
        getDoador();
    }, []);
    return(
        <>
            <Header/>
            <div className={styles.Doador}>
                <div className={styles.tabela}>
                    <table className="table table-success table-striped-columns">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>CPF</th>
                                <th>Nome</th>
                                <th>Tipo</th>
                                <th>Quantidade</th>
                            </tr>
                        </thead>
                        <tbody>
                        {doador.map((doador) => (
                            <tr key={doador.id}>
                                <td>{doador.id}</td>
                                <td>{doador.cpf}</td>
                                <td>{doador.nome}</td>
                                <td>{doador.tipo}</td>
                                <td>{doador.quantidade}</td>
                            </tr>
                        ))}
                        </tbody>
                    </table>

                </div>
            </div>
        </>
    )
}
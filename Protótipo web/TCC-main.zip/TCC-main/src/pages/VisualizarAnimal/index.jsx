import styles from './visualizar.module.css';
import Header from '../../components/Header';
import endFetch from '../../axios';
import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useEffect } from 'react';
import animais from '../../image/animais.png';

export default function VisualizarAnimal(){
    const { id } = useParams();
    const [animal, setAnimal] = useState({
        nome: '',
        especie: '',
        idade: '',
        status: '',
        historia:'',
        protese:'',
        imagem:'',
    });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    const getAnimal = async () => {
        try {
            const response = await endFetch.get(`/animais/${id}`);
            setAnimal(response.data);
            setLoading(false);
        } catch (error) {
            setLoading(false);
            setError('Erro ao carregar os dados do animal');
            console.log(error);
        }
    };

    useEffect(() => {
        getAnimal();
    }, [id]);

    if (loading) {
        return <div>Carregando...</div>;
    }

    return(
        <>        
        <Header/>
        <div className={styles.vizualizar}>
            
            <Link to={'/Animal'}><p className={styles.voltar}>Voltar</p></Link>
            <h1 className={styles.titulo}>Ficha Animal</h1>

            <div className={styles.nathan}>
                <div className={styles.imagem}>
                    <img src={animal.imagem} alt={animal.nome} />
                    <h1>{animal.nome}</h1>
                </div>

                <div className={styles.informacoes}>
                    
                    <div className={styles.dados}>
                        <p className={styles.caracteristica}>ID do animal</p>
                        <div className={styles.animal}>
                            <p>{animal.id}</p>
                        </div>
                    </div>
                    
                    <div className={styles.dados}>
                        <p className={styles.caracteristica}>Espécie</p>
                        <div className={styles.animal}>
                            <p>{animal.especie}</p>
                        </div>
                    </div>

                    <div className={styles.dados}>
                        <p className={styles.caracteristica}>Idade</p>
                        <div className={styles.animal}>
                            <p>{animal.idade}</p>
                        </div>
                    </div>

                    <div className={styles.dados}>
                        <p className={styles.caracteristica}>Status</p>
                        <div className={styles.animal}>
                            <p>{animal.status}</p>
                        </div>
                    </div>

                    <div className={styles.dados}>
                        <p className={styles.caracteristica}>Necessidade de Protése</p>
                        <div className={styles.animal}>
                            <p>{animal.protese}</p>
                        </div>
                    </div>

                    <div className={styles.dados}>
                        <p className={styles.caracteristica}>Historia</p>
                        <div className={styles.animal}>
                            <p>{animal.historia}</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        </>

    )
}
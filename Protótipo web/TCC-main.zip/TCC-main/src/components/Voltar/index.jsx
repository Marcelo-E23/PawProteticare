import styles from './voltar.module.css'

export default function Voltar(){
    return(
        <>
            <p className={styles.voltar}>Voltar</p>
        </>
    )

}
package com.br.pawproteticare.apipawproteticare.model.service;

import java.util.List;

import com.br.pawproteticare.apipawproteticare.model.entity.PawProteticare;

public interface PawProteticareService {
    List<PawProteticare> mostrarDados();
}
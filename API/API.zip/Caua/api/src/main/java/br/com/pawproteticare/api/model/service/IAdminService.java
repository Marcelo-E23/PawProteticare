package br.com.pawproteticare.api.model.service;

import br.com.pawproteticare.api.model.entity.Admin;
import br.com.pawproteticare.api.model.entity.Proprietario;

public interface IAdminService {


    Admin salvar(Admin admin);


}

package br.com.pawproteticare.api.model.service;

import br.com.pawproteticare.api.model.entity.Doador;
import br.com.pawproteticare.api.model.entity.Proprietario;
import br.com.pawproteticare.api.model.entity.UsuarioEntity;

public interface IDoadorService {





}

package br.com.pawproteticare.api.token;

public enum TokenType {
    BEARER
}

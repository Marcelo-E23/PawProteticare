package br.com.pawproteticare.api.model.enums;

public enum StatusAdocao {
    APROVADO,
    REPROVADO,
    AGUARDANDO_AVALIACAO
}

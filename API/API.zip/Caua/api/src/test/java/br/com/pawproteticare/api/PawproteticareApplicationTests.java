package br.com.pawproteticare.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PawproteticareApplicationTests {

	@Test
	void contextLoads() {
	}

}

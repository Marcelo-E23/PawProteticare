
allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

subprojects {
//    project.evaluationDependsOn(":app")
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
